<?php

$db = mysqli_connect($db_host,$db_user,$db_pass,$db_name);
if (!$db){ die ("Es imposible conectar con la bbdd ".$db_name."</br>".mysqli_connect_error()."</br>
    
                    </div>
                <!--
                ////////////////////////////////
                ////////////////////////////////
                    Fin contenedor de datos.
                ////////////////////////////////
                ////////////////////////////////
                -->
 
                    <div style=\"clear:both\"></div>

                    <!-- Inicio footer -->
                    <div id=\"footer\">&copy; Juan Barr&oacute;s Pazos 2020.</div>
                    <!-- Fin footer -->

                    </div>

                </body>

            </html> ");
            
            }
            
?>