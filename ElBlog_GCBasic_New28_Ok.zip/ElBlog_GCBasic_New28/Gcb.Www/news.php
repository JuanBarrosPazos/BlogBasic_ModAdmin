<!DOCTYPE html>
<html lang="en">

<head>

  <title>Juan Barros Pazos - About</title>

  <?php require 'Inc_Header_Nav_Head.php'; ?>

  <!-- About -->
  <section class="page-section" id="about">
    <div class="container">

    <?php require '../Gcb.Artic/Articulo_Ver_news.php'; ?>

  </div> <!-- Fin container -->
</section>

  <?php require 'Inc_Footer.php';  ?> 

  <?php require 'Inc_Jquery_Boots_Foot.php';  ?>

</body>

</html>
